import os
import re
import shutil
from collections import defaultdict

def duplicate_text_files(directory):
    """
    Duplicates text files to match corresponding image files based on prefixes.
    For each image file without a corresponding text file, creates one by copying
    the text file that matches the prefix.
    """
    # Get all files in the directory
    all_files = os.listdir(directory)
    
    # Separate image and text files
    image_files = [f for f in all_files if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
    text_files = [f for f in all_files if f.lower().endswith('.txt')]
    
    # Group files by their base names (prefix)
    image_groups = defaultdict(list)
    text_groups = defaultdict(list)
    
    # Regular expression to extract the prefix and suffix
    pattern = r'(.*?)_(\d{5})_\..*$'
    
    # Group image files by prefix
    for img_file in image_files:
        match = re.match(pattern, img_file)
        if match:
            prefix = match.group(1)  # The base name part
            image_groups[prefix].append(img_file)
    
    # Group text files by prefix
    for txt_file in text_files:
        # Check if this follows our naming pattern
        match = re.match(pattern, txt_file)
        if match:
            prefix = match.group(1)
            text_groups[prefix].append(txt_file)
        # Also handle the case where we have just "prefix.txt" without numbering
        elif txt_file.endswith('.txt'):
            prefix = os.path.splitext(txt_file)[0]
            if prefix in image_groups:
                text_groups[prefix].append(txt_file)
    
    # Count of created files
    created_files = 0
    
    # For each image group, ensure there's a matching text file
    for prefix, img_files in image_groups.items():
        # Find a source text file to copy from
        source_text = None
        
        # First, check if we have a text file with the same prefix and "_00001_" suffix
        for txt in text_groups.get(prefix, []):
            if "_00001_" in txt:
                source_text = txt
                break
        
        # If not found, use any text file with the same prefix
        if not source_text and text_groups.get(prefix):
            source_text = text_groups[prefix][0]
        
        # If we found a source text file, create matching text files for all images
        if source_text:
            source_path = os.path.join(directory, source_text)
            
            for img_file in img_files:
                # Extract the suffix from the image filename
                match = re.match(pattern, img_file)
                if match:
                    suffix = match.group(2)  # The numeric suffix
                    target_text = f"{prefix}_{suffix}_.txt"
                    target_path = os.path.join(directory, target_text)
                    
                    # Check if the target file already exists
                    if not os.path.exists(target_path):
                        shutil.copy2(source_path, target_path)
                        created_files += 1
                        print(f"Created {target_text}")
    
    print(f"\nComplete! Created {created_files} new text files.")

if __name__ == "__main__":
    # Get the directory from user input or use current directory
    directory = input("Enter the directory path (press Enter for current directory): ")
    if not directory:
        directory = "."
    
    # Run the function
    duplicate_text_files(directory)
